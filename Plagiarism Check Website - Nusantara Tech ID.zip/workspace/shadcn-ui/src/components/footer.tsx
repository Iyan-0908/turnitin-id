export function Footer() {
  return (
    <footer className="border-t py-6 md:py-8">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row px-4 md:px-6">
        <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
          © {new Date().getFullYear()} TurnitinCheck. All rights reserved.
        </p>
        <p className="md:text-left bg-[#00000000] mt-[0px] mr-[0px] mb-[0px] ml-[0px] pt-[0px] pr-[0px] pb-[0px] pl-[0px] text-[14px] font-normal text-left font-sans opacity-100 text-[#64748B]">
          Developed by Nusantara Tech ID
        </p>
      </div>
    </footer>
  );
}
