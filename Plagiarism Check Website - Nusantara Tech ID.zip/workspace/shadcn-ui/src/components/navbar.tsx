import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { FileCheck2, GitCompareArrows } from "lucide-react";
import { Link } from "react-router-dom";

export function Navbar() {
  return (
    <nav className="w-full border-b sticky top-0 z-50 bg-background">
      <div className="container flex items-center justify-between h-16 px-4 mx-auto sm:px-6">
        <Link to="/" className="flex items-center space-x-2">
          <GitCompareArrows className="h-6 w-6 text-blue-600" />
          <span className="bg-[#00000000] mt-[0px] mr-[0px] mb-[0px] ml-[8px] pt-[0px] pr-[0px] pb-[0px] pl-[0px] text-[18px] font-bold font-sans opacity-100 text-[#020817]">Turnitin Check Indonesia</span>
        </Link>
        <div className="flex items-center space-x-4">
          <Link to="/" className="hidden md:flex">
            <Button variant="ghost" className="gap-2">
              <FileCheck2 className="h-4 w-4" />
              Check Document
            </Button>
          </Link>
          <ThemeToggle />
        </div>
      </div>
    </nav>
  );
}
