import { useState } from "react";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { ApiKeyForm } from "@/components/api-key-form";
import { DocumentUpload } from "@/components/document-upload";
import { ResultDisplay } from "@/components/result-display";
import { turnitinService } from "@/lib/turnitin-service";
import { useToast } from "@/components/ui/use-toast";
import { AlertCircle, Check } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function Index() {
  const { toast } = useToast();
  const [apiKey, setApiKey] = useState<string | null>(turnitinService.getApiKey());
  const [isChecking, setIsChecking] = useState(false);
  const [results, setResults] = useState<{
    aiSimilarity: number;
    plagiarismScore: number;
    aiDetails?: string;
    plagiarismDetails?: string;
    aiReport?: Blob;
    plagiarismReport?: Blob;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleApiKeySubmit = (key: string) => {
    try {
      turnitinService.setApiKey(key);
      setApiKey(key);
      setError(null);
      toast({
        title: "API Key Saved",
        description: "Your Turnitin API key has been saved successfully.",
        duration: 3000,
      });
    } catch (err) {
      setError("Failed to save API key. Please try again.");
    }
  };

  const handleDocumentSubmit = async (
    file: File,
    excludeReferences: boolean,
    excludeFootnotes: boolean
  ) => {
    setIsChecking(true);
    setError(null);
    setResults(null);

    try {
      const result = await turnitinService.checkDocument(file, {
        excludeReferences,
        excludeFootnotes,
      });

      setResults(result);
      toast({
        title: "Check Complete",
        description: "Document analysis has been completed successfully.",
        duration: 3000,
      });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred during document check.";
      setError(errorMessage);
    } finally {
      setIsChecking(false);
    }
  };

  const handleDownloadAiResult = () => {
    if (results?.aiReport) {
      const url = URL.createObjectURL(results.aiReport);
      const a = document.createElement("a");
      a.href = url;
      a.download = "ai-similarity-report.txt";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const handleDownloadPlagiarismResult = () => {
    if (results?.plagiarismReport) {
      const url = URL.createObjectURL(results.plagiarismReport);
      const a = document.createElement("a");
      a.href = url;
      a.download = "plagiarism-report.txt";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1 container py-8 px-4">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
              Plagiarism & AI Similarity Checker
            </h1>
            <p className="text-xl text-muted-foreground">
              Check your document for plagiarism and AI-generated content using Turnitin
            </p>
          </div>

          {error && (
            <Alert variant="destructive" className="mx-auto max-w-xl">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {!apiKey ? (
            <ApiKeyForm onApiKeySubmit={handleApiKeySubmit} />
          ) : (
            <div className="space-y-8">
              <Alert className="mx-auto max-w-xl bg-green-50 dark:bg-green-950/20">
                <Check className="h-4 w-4 text-green-600" />
                <AlertTitle>API Key Configured</AlertTitle>
                <AlertDescription>
                  Your Turnitin API key has been set. You can now check documents.
                </AlertDescription>
              </Alert>

              <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
                <div>
                  <DocumentUpload 
                    onDocumentSubmit={handleDocumentSubmit}
                    isLoading={isChecking}
                  />
                </div>
                {results ? (
                  <div>
                    <ResultDisplay 
                      results={results}
                      onDownloadAiResult={handleDownloadAiResult}
                      onDownloadPlagiarismResult={handleDownloadPlagiarismResult}
                    />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center p-8 border rounded-lg bg-muted/30">
                      <h3 className="text-lg font-medium mb-2">
                        No Results Yet
                      </h3>
                      <p className="text-muted-foreground">
                        Upload and check a document to see plagiarism and AI similarity results here.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}