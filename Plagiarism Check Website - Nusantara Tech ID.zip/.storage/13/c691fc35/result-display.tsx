import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Award, Download, FileText } from "lucide-react";

interface ResultDisplayProps {
  results: {
    aiSimilarity: number;
    plagiarismScore: number;
    aiDetails?: string;
    plagiarismDetails?: string;
  };
  onDownloadAiResult: () => void;
  onDownloadPlagiarismResult: () => void;
}

export function ResultDisplay({
  results,
  onDownloadAiResult,
  onDownloadPlagiarismResult,
}: ResultDisplayProps) {
  return (
    <Tabs defaultValue="scores" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="scores">Scores</TabsTrigger>
        <TabsTrigger value="details">Details</TabsTrigger>
      </TabsList>

      <TabsContent value="scores" className="space-y-4 pt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-blue-600" />
                  AI Similarity
                </span>
                <span 
                  className={`text-xl font-bold ${
                    results.aiSimilarity > 50 
                      ? "text-red-500" 
                      : results.aiSimilarity > 20 
                        ? "text-yellow-500" 
                        : "text-green-500"
                  }`}
                >
                  {results.aiSimilarity}%
                </span>
              </CardTitle>
              <CardDescription>
                Percentage of content that appears to be AI-generated
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress
                value={results.aiSimilarity}
                className={`h-2 ${
                  results.aiSimilarity > 50 
                    ? "bg-red-100" 
                    : results.aiSimilarity > 20 
                      ? "bg-yellow-100" 
                      : "bg-green-100"
                }`}
              />
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={onDownloadAiResult}
              >
                <Download className="mr-2 h-4 w-4" />
                Download AI Check Results
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-600" />
                  Plagiarism Score
                </span>
                <span 
                  className={`text-xl font-bold ${
                    results.plagiarismScore > 30 
                      ? "text-red-500" 
                      : results.plagiarismScore > 10 
                        ? "text-yellow-500" 
                        : "text-green-500"
                  }`}
                >
                  {results.plagiarismScore}%
                </span>
              </CardTitle>
              <CardDescription>
                Percentage of content that matches existing sources
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress
                value={results.plagiarismScore}
                className={`h-2 ${
                  results.plagiarismScore > 30 
                    ? "bg-red-100" 
                    : results.plagiarismScore > 10 
                      ? "bg-yellow-100" 
                      : "bg-green-100"
                }`}
              />
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={onDownloadPlagiarismResult}
              >
                <Download className="mr-2 h-4 w-4" />
                Download Plagiarism Results
              </Button>
            </CardFooter>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="details" className="space-y-4 pt-4">
        <Card>
          <CardHeader>
            <CardTitle>Detailed Results</CardTitle>
            <CardDescription>
              Comprehensive analysis of your document
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold mb-2">AI Similarity Analysis</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-line">
                {results.aiDetails || "No detailed AI analysis available."}
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">Plagiarism Analysis</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-line">
                {results.plagiarismDetails || "No detailed plagiarism analysis available."}
              </p>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}