import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Upload } from "lucide-react";

interface DocumentUploadProps {
  onDocumentSubmit: (
    file: File, 
    excludeReferences: boolean, 
    excludeFootnotes: boolean
  ) => void;
  isLoading: boolean;
}

export function DocumentUpload({
  onDocumentSubmit,
  isLoading,
}: DocumentUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [excludeReferences, setExcludeReferences] = useState(true);
  const [excludeFootnotes, setExcludeFootnotes] = useState(true);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file) {
      onDocumentSubmit(file, excludeReferences, excludeFootnotes);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Upload Document</CardTitle>
        <CardDescription>
          Upload your document to check for plagiarism and AI similarity
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="document">Document (.docx, .pdf, .txt)</Label>
            <Input
              id="document"
              type="file"
              accept=".docx,.pdf,.txt"
              onChange={handleFileChange}
              required
            />
          </div>
          <div className="flex flex-col gap-3">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="exclude-references" 
                checked={excludeReferences}
                onCheckedChange={(checked) => 
                  setExcludeReferences(checked === true)
                }
              />
              <Label htmlFor="exclude-references">
                Exclude bibliography/references
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="exclude-footnotes" 
                checked={excludeFootnotes}
                onCheckedChange={(checked) => 
                  setExcludeFootnotes(checked === true)
                }
              />
              <Label htmlFor="exclude-footnotes">
                Exclude footnotes
              </Label>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            type="submit" 
            className="w-full" 
            disabled={!file || isLoading}
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                Processing...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Upload className="h-4 w-4" />
                Check Document
              </span>
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}