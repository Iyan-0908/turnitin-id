// This is a mock implementation of the Turnitin service
// In production, this would interact with the actual Turnitin API

interface CheckOptions {
  excludeReferences: boolean;
  excludeFootnotes: boolean;
}

interface CheckResult {
  aiSimilarity: number;
  plagiarismScore: number;
  aiDetails: string;
  plagiarismDetails: string;
  aiReport: Blob;
  plagiarismReport: Blob;
}

export class TurnitinService {
  private apiKey: string | null = null;

  setApiKey(apiKey: string) {
    this.apiKey = apiKey;
    localStorage.setItem('turnitin-api-key', apiKey);
    return true;
  }

  getApiKey(): string | null {
    if (!this.apiKey) {
      this.apiKey = localStorage.getItem('turnitin-api-key');
    }
    return this.apiKey;
  }

  clearApiKey() {
    this.apiKey = null;
    localStorage.removeItem('turnitin-api-key');
  }

  async checkDocument(
    file: File, 
    options: CheckOptions
  ): Promise<CheckResult> {
    if (!this.apiKey) {
      throw new Error('API key not set');
    }

    // Simulate API call with a delay
    return new Promise((resolve) => {
      setTimeout(() => {
        // Generate random results for demo purposes
        // In a real implementation, this would call the Turnitin API
        const aiSimilarity = Math.floor(Math.random() * 100);
        const plagiarismScore = Math.floor(Math.random() * 100);

        // Create mock reports
        const aiReport = new Blob([
          `AI Similarity Report\n\nDocument: ${file.name}\nTimestamp: ${new Date().toISOString()}\nAI Similarity Score: ${aiSimilarity}%\n\nOptions:\n- Exclude References: ${options.excludeReferences}\n- Exclude Footnotes: ${options.excludeFootnotes}`
        ], { type: 'text/plain' });

        const plagiarismReport = new Blob([
          `Plagiarism Report\n\nDocument: ${file.name}\nTimestamp: ${new Date().toISOString()}\nPlagiarism Score: ${plagiarismScore}%\n\nOptions:\n- Exclude References: ${options.excludeReferences}\n- Exclude Footnotes: ${options.excludeFootnotes}`
        ], { type: 'text/plain' });

        // Generate sample analysis details
        const aiDetails = this._generateAIDetails(aiSimilarity);
        const plagiarismDetails = this._generatePlagiarismDetails(plagiarismScore);

        resolve({
          aiSimilarity,
          plagiarismScore,
          aiDetails,
          plagiarismDetails,
          aiReport,
          plagiarismReport
        });
      }, 2000); // Simulate 2-second API call
    });
  }

  private _generateAIDetails(score: number): string {
    const details = [
      `AI Similarity Score: ${score}%`,
      '\nAnalysis Summary:',
    ];

    if (score > 70) {
      details.push('\n- High probability of AI-generated content');
      details.push('\n- Detected consistent language patterns typical of AI writing');
      details.push('\n- Limited unique stylistic markers');
    } else if (score > 40) {
      details.push('\n- Moderate indicators of AI assistance');
      details.push('\n- Some sections show patterns consistent with AI generation');
      details.push('\n- Mixed writing styles detected');
    } else {
      details.push('\n- Low probability of AI-generated content');
      details.push('\n- Natural language variations throughout the document');
      details.push('\n- Inconsistencies and stylistic markers typical of human writing');
    }

    return details.join(' ');
  }

  private _generatePlagiarismDetails(score: number): string {
    const details = [
      `Plagiarism Score: ${score}%`,
      '\nAnalysis Summary:',
    ];

    if (score > 50) {
      details.push('\n- High level of matching content detected');
      details.push('\n- Multiple passages match existing sources without proper citation');
      details.push('\n- Consider revising with appropriate citations or paraphrasing');
    } else if (score > 20) {
      details.push('\n- Moderate matching content detected');
      details.push('\n- Some passages may require citation or revision');
      details.push('\n- Check highlighted sections for potential citation needs');
    } else {
      details.push('\n- Low level of matching content');
      details.push('\n- Few or no significant matches to existing sources');
      details.push('\n- Content appears to be original or properly cited');
    }

    return details.join(' ');
  }
}

export const turnitinService = new TurnitinService();